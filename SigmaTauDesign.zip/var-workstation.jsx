// var-workstation.jsx — SigmaTau workstation (direction C, iterated)
// Brand purple #b26fd9 accent · σ(τ) wordmark
// State-driven: toolbar pills, dataset rows, layer toggles, inspector tabs
// are all interactive. Sidebar swappable via `sidebar` prop: stacked|rail|hub.

const { useState, useEffect, useRef } = React;

const wsTheme = {
  id: 'ws',
  bg: '#16161a',
  panel: '#1c1c20',
  panelAlt: '#26262c',
  panelDeep: '#111114',
  border: '#2a2a30',
  borderStrong: '#3a3a42',
  fg: '#ececea',
  fgDim: '#c0c0bc',
  muted: '#8a8a84',
  mutedDim: '#5a5a56',
  // brand & accent
  accent: '#b26fd9',
  accentDim: '#6d3f8c',
  accentSoft: '#3a2247',
  tau: '#cfcfca',
  ok: '#9ed968',
  warn: '#e9b754',
  err: '#e87862',
  // plot
  plotBg: '#101013',
  grid: '#2a2a30',
  gridMinor: '#1d1d22',
  axis: '#5a5a60',
  fitColor: '#a89870',
  cursor: '#b26fd9',
  readoutBg: 'rgba(15,15,17,0.95)',
  readoutBorder: '#3a3a42',
  // traces
  t1: '#e9b754',  // ADEV — gold
  t2: '#5dd2b8',  // MDEV — teal
  t3: '#ff8b6e',  // HDEV — coral
  t4: '#7ab8ff',  // TDEV — blue
  ghost: '#5e6068',
  fontUI: '"Inter", -apple-system, system-ui, sans-serif',
  fontMono: '"JetBrains Mono", "IBM Plex Mono", monospace',
};

// ─── data models ───────────────────────────────────────────────
// A dataset holds phase OR frequency data. From it we compute σ(τ)
// estimators (ADEV/MDEV/HDEV/TDEV), drift fits, masks, PSD, etc. — these
// are children of the dataset, not a flat layer list.
const DATASETS = [
  { id: 'cs5071',  name: 'Cs5071A_vs_HMaser03', kind: 'phase', pts: '99 999',  mtime: 'today', floor: '1.52e-14',
    meta: { drift: '+1.74e-14 /s · linear · removed', mask: '142 outliers · ±5σ MAD' } },
  { id: 'ocxo-a',  name: 'OCXO-A_vs_HMaser03',  kind: 'phase', pts: '86 400',  mtime: '2d',    floor: '6.4e-13',
    meta: { drift: '+8.21e-12 /s · removed',         mask: '0 outliers' } },
  { id: 'maser03', name: 'MASER-03_drift',       kind: 'freq',  pts: '41 000',  mtime: '4d',    floor: '8.2e-15',
    meta: { drift: '—', mask: '—' } },
  { id: 'rb-02',   name: 'Rb-02_temp_step',      kind: 'phase', pts: '100 000', mtime: '11d',   floor: '4.1e-13',
    meta: { drift: '+3.04e-13 /s · removed',         mask: '8 outliers' } },
];
const METRICS = [
  { id: 'ADEV', color: wsTheme.t1 },
  { id: 'MDEV', color: wsTheme.t2 },
  { id: 'HDEV', color: wsTheme.t3 },
  { id: 'TDEV', color: wsTheme.t4 },
];
const SECONDARY = [{ id: 'MTIE' }, { id: 'TIE-rms' }, { id: 'θ₁' }];
const INSPECTOR_TABS = ['Run', 'Stats', 'Noise', 'Masks', 'Log'];

// Per-dataset run state — which σ(τ) estimators are computed & shown on plot
const INITIAL_RUNS = {
  cs5071:   { ADEV: true,  MDEV: true,  HDEV: true,  TDEV: false },
  'ocxo-a': { ADEV: true,  MDEV: false, HDEV: false, TDEV: false },  // overlay
  maser03:  { ADEV: false, MDEV: false, HDEV: false, TDEV: false },
  'rb-02':  { ADEV: false, MDEV: false, HDEV: false, TDEV: false },
};

// ─── main window ───────────────────────────────────────────────
function WSWindow({ sidebar = 'stacked' }) {
  const [datasetRuns, setDatasetRuns] = useState(INITIAL_RUNS);
  const [datasetId, setDatasetId]     = useState('cs5071');
  const [expanded, setExpanded]       = useState(new Set(['cs5071']));
  const [phaseMode, setPhaseMode]     = useState('phase');
  const [inspectorTab, setInspectorTab] = useState('Stats');
  const [overlap, setOverlap] = useState(true);

  const toggleRun = (dsId, m) => setDatasetRuns((p) => ({
    ...p, [dsId]: { ...p[dsId], [m]: !p[dsId]?.[m] }
  }));
  const toggleExpand = (id) => setExpanded((p) => {
    const n = new Set(p); n.has(id) ? n.delete(id) : n.add(id); return n;
  });
  const selectDataset = (id) => {
    setDatasetId(id);
    setExpanded((p) => new Set([...p, id]));
  };

  const activeDs    = DATASETS.find((d) => d.id === datasetId);
  const activeRuns  = datasetRuns[datasetId] || {};
  const tracesInPlot = ['ADEV', 'MDEV', 'HDEV', 'TDEV'].filter((m) => activeRuns[m]);
  // Overlay = other datasets that have ADEV computed (shown dashed)
  const overlayDsId = Object.keys(datasetRuns).find((k) => k !== datasetId && datasetRuns[k].ADEV);
  const overlayDs   = overlayDsId ? DATASETS.find((d) => d.id === overlayDsId) : null;
  const overlayData = overlayDs ? { ADEV: ADEV.map((v) => v * (overlayDsId === 'ocxo-a' ? 4.2 : overlayDsId === 'maser03' ? 0.4 : 2.5)) } : null;

  return (
    <div style={{
      width: '100%', height: '100%',
      background: wsTheme.bg, color: wsTheme.fg,
      fontFamily: wsTheme.fontUI, fontSize: 11.5,
      display: 'flex', flexDirection: 'column', overflow: 'hidden',
    }}>
      {/* Title bar */}
      <div style={{ height: 38, background: wsTheme.panelDeep, borderBottom: `1px solid ${wsTheme.border}`, display: 'flex', alignItems: 'stretch' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 7, padding: '0 14px 0 12px' }}>
          <div style={{ width: 11, height: 11, borderRadius: 6, background: '#ff5f57' }} />
          <div style={{ width: 11, height: 11, borderRadius: 6, background: '#febc2e' }} />
          <div style={{ width: 11, height: 11, borderRadius: 6, background: '#28c840' }} />
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '0 16px', borderRight: `1px solid ${wsTheme.border}`, borderLeft: `1px solid ${wsTheme.border}` }}>
          <SigmaTauMark />
        </div>
        <div style={{ display: 'flex', alignItems: 'center', padding: '0 4px 0 10px' }}>
          {['File', 'Edit', 'Data', 'Compute', 'Mask', 'Compare', 'Export', 'View', 'Window', 'Help'].map((m) => (
            <span key={m} style={{ padding: '0 8px', fontSize: 11.5, color: wsTheme.muted, lineHeight: 1, cursor: 'default' }}>{m}</span>
          ))}
        </div>
        <div style={{ flex: 1 }} />
        <div style={{ display: 'flex', alignItems: 'center', fontSize: 11, color: wsTheme.muted, fontFamily: wsTheme.fontMono, padding: '0 14px' }}>
          workspace<span style={{ color: wsTheme.mutedDim, margin: '0 6px' }}>/</span><span style={{ color: wsTheme.fg }}>atomic_clock_review</span>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '0 16px', borderLeft: `1px solid ${wsTheme.border}`, fontFamily: wsTheme.fontMono, fontSize: 10.5, color: wsTheme.muted }}>
          <span><span style={{ color: wsTheme.mutedDim }}>CPU</span> 12%</span>
          <span><span style={{ color: wsTheme.mutedDim }}>MEM</span> 384 MB</span>
          <span style={{ display: 'flex', alignItems: 'center', gap: 5, color: wsTheme.fgDim }}>
            <span style={{ width: 6, height: 6, borderRadius: 3, background: wsTheme.ok }} />
            solver idle
          </span>
        </div>
      </div>

      {/* Toolbar */}
      <div style={{ height: 32, background: wsTheme.panel, borderBottom: `1px solid ${wsTheme.border}`, display: 'flex', alignItems: 'center', padding: '0 8px', gap: 4 }}>
        <WSGroup>
          <WSPill label="Phase" active={phaseMode === 'phase'} onClick={() => setPhaseMode('phase')} />
          <WSPill label="Freq"  active={phaseMode === 'freq'}  onClick={() => setPhaseMode('freq')}  />
        </WSGroup>
        <WSSep />
        <WSGroup>
          {METRICS.map((m) => (
            <WSPill
              key={m.id}
              label={m.id}
              active={!!activeRuns[m.id]}
              glyph="●" color={m.color}
              onClick={() => toggleRun(datasetId, m.id)}
            />
          ))}
          {SECONDARY.map((m) => (
            <WSPill key={m.id} label={m.id} />
          ))}
        </WSGroup>
        <WSSep />
        <WSGroup>
          <WSPill label="overlap" active={overlap} onClick={() => setOverlap((o) => !o)} />
          <WSPill label="m: 2ⁿ" />
        </WSGroup>
        <WSSep />
        <WSGroup>
          <WSPill label="drift: lin ✓" active />
          <WSPill label="mask: 142" warn />
        </WSGroup>
        <div style={{ flex: 1 }} />
        <span style={{ fontFamily: wsTheme.fontMono, fontSize: 10.5, color: wsTheme.mutedDim, padding: '0 12px' }}>F5 Recompute · ⌘E Export · ⌘K Cmd</span>
        <WSPill label="Run all" primary onClick={() => {}} />
      </div>

      {/* Body */}
      <div style={{ flex: 1, display: 'flex', minHeight: 0 }}>
        <WSLeftSidebar
          variant={sidebar}
          datasetId={datasetId} selectDataset={selectDataset}
          datasetRuns={datasetRuns} toggleRun={toggleRun}
          expanded={expanded} toggleExpand={toggleExpand}
        />

        {/* Center column */}
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', minWidth: 0, background: wsTheme.bg }}>
          <div style={{ height: 28, borderBottom: `1px solid ${wsTheme.border}`, background: wsTheme.panel, display: 'flex', alignItems: 'center', padding: '0 12px', gap: 8, fontSize: 11 }}>
            <span style={{ color: wsTheme.fgDim, fontWeight: 600 }}>σ–τ · log-log</span>
            <span style={{ color: wsTheme.mutedDim }}>·</span>
            <span style={{ color: wsTheme.muted, fontFamily: wsTheme.fontMono }}>{activeDs.name}</span>
            <span style={{ color: wsTheme.mutedDim }}>·</span>
            <span style={{ color: wsTheme.muted, fontFamily: wsTheme.fontMono }}>
              x ∈ [1, 32 768] s   y ∈ [10⁻¹⁵, 10⁻¹⁰]
            </span>
            <div style={{ flex: 1 }} />
            <span style={{ display: 'flex', alignItems: 'center', gap: 6, color: wsTheme.muted, fontFamily: wsTheme.fontMono, fontSize: 10.5 }}>
              <span style={{ width: 8, height: 8, borderRadius: 4, background: wsTheme.cursor }} />
              cursor τ = 512 s · σ = 1.51e-13
            </span>
          </div>
          <div style={{ flex: 1, padding: 16, position: 'relative' }}>
            <SigmaTauPlot
              theme={wsTheme}
              width={780} height={430}
              pad={{ t: 24, r: 28, b: 50, l: 70 }}
              traces={tracesInPlot}
              comparison={overlayData}
              showErrorBars showFit showCursor showNoiseBands
              cursorIdx={9}
              axisStyle="graticule"
            />
          </div>
          {/* Bottom strip */}
          <div style={{ height: 180, borderTop: `1px solid ${wsTheme.border}`, background: wsTheme.panel, display: 'flex' }}>
            <div style={{ flex: 1, borderRight: `1px solid ${wsTheme.border}`, padding: '8px 12px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
                <span style={{ fontSize: 10.5, color: wsTheme.muted, letterSpacing: 0.5, fontWeight: 600 }}>{phaseMode === 'phase' ? 'PHASE  x(t)' : 'FREQUENCY  y(t)'}</span>
                <span style={{ fontSize: 10, color: wsTheme.mutedDim, fontFamily: wsTheme.fontMono }}>{phaseMode === 'phase' ? 'ns · drift removed' : 'parts in 10¹² · 142 masked'}</span>
              </div>
              <TimeSeriesPlot theme={wsTheme} width={400} height={132} kind={phaseMode} />
            </div>
            <div style={{ flex: 1, borderRight: `1px solid ${wsTheme.border}`, padding: '8px 12px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
                <span style={{ fontSize: 10.5, color: wsTheme.muted, letterSpacing: 0.5, fontWeight: 600 }}>{phaseMode === 'phase' ? 'FREQUENCY  y(t)' : 'PHASE  x(t)'}</span>
                <span style={{ fontSize: 10, color: wsTheme.mutedDim, fontFamily: wsTheme.fontMono }}>{phaseMode === 'phase' ? 'parts in 10¹² · 142 masked' : 'ns · drift removed'}</span>
              </div>
              <TimeSeriesPlot theme={wsTheme} width={400} height={132} kind={phaseMode === 'phase' ? 'freq' : 'phase'} />
            </div>
            <div style={{ width: 240, padding: '8px 12px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
                <span style={{ fontSize: 10.5, color: wsTheme.muted, letterSpacing: 0.5, fontWeight: 600 }}>HISTOGRAM</span>
                <span style={{ fontSize: 10, color: wsTheme.mutedDim, fontFamily: wsTheme.fontMono }}>n=99 857</span>
              </div>
              <Histogram theme={wsTheme} width={220} height={132} />
            </div>
          </div>
        </div>

        {/* Right inspector */}
        <div style={{ width: 304, borderLeft: `1px solid ${wsTheme.border}`, background: wsTheme.panel, display: 'flex', flexDirection: 'column' }}>
          <div style={{ height: 28, display: 'flex', borderBottom: `1px solid ${wsTheme.border}`, background: wsTheme.panelDeep }}>
            {INSPECTOR_TABS.map((t) => {
              const sel = inspectorTab === t;
              return (
                <div
                  key={t}
                  onClick={() => setInspectorTab(t)}
                  style={{ padding: '0 12px', height: 28, display: 'flex', alignItems: 'center', fontSize: 11,
                    color: sel ? wsTheme.fg : wsTheme.muted,
                    borderBottom: sel ? `2px solid ${wsTheme.accent}` : '2px solid transparent',
                    borderRight: `1px solid ${wsTheme.border}`,
                    fontWeight: sel ? 600 : 500, cursor: 'pointer', userSelect: 'none' }}
                >{t}</div>
              );
            })}
          </div>
          <div style={{ flex: 1, overflow: 'auto', fontFamily: wsTheme.fontMono, fontSize: 11 }}>
            <WSInspectorContent tab={inspectorTab} dataset={activeDs} />
          </div>
        </div>
      </div>

      {/* Log strip */}
      <div style={{ height: 96, borderTop: `1px solid ${wsTheme.border}`, background: wsTheme.panelDeep, display: 'flex' }}>
        <div style={{ width: 124, borderRight: `1px solid ${wsTheme.border}`, padding: '6px 10px', fontSize: 10.5, color: wsTheme.muted, lineHeight: 1.8, fontFamily: wsTheme.fontMono }}>
          <div style={{ color: wsTheme.fg, fontWeight: 600 }}>LOG</div>
          <div>Console</div>
          <div style={{ color: wsTheme.mutedDim }}>Errors</div>
          <div style={{ color: wsTheme.mutedDim }}>Profiler</div>
        </div>
        <div style={{ flex: 1, padding: '6px 12px', fontFamily: wsTheme.fontMono, fontSize: 10.5, lineHeight: 1.7, color: wsTheme.fgDim, overflow: 'hidden' }}>
          <LogLine ts="14:08:42" lvl="info" msg={`loaded ${activeDs.name}.tim · ${activeDs.pts} phase samples · τ₀ = 1.000 s`} />
          <LogLine ts="14:08:43" lvl="info" msg="142 outliers detected at ±5σ MAD → masked" />
          <LogLine ts="14:08:43" lvl="info" msg="linear drift fit: a = +1.74e-14 /s, b = +3.21e-13 → removed" />
          <LogLine ts="14:08:51" lvl="ok"   msg={`computed overlapping ${Object.keys(activeRuns).filter((k) => activeRuns[k]).join('/') || '—'} across 15 τ in 312 ms · cache stored`} />
          <LogLine ts="14:08:52" lvl="info" msg="noise ID (B1, lag-1 R(n)): τ≤64 W FM · 64<τ≤1024 F FM · τ>1024 RW FM" />
          <LogLine ts="14:09:01" lvl="warn" msg="τ = 16 384 → EDF = 5.9 · CI is wide; consider longer record" />
        </div>
      </div>
    </div>
  );
}

// ─── inspector content per tab ───────────────────────────────
function WSInspectorContent({ tab, dataset }) {
  if (tab === 'Stats') return <InspStats />;
  if (tab === 'Run')   return <InspRun dataset={dataset} />;
  if (tab === 'Noise') return <InspNoise />;
  if (tab === 'Masks') return <InspMasks />;
  if (tab === 'Log')   return <InspLog />;
  return null;
}
function InspStats() {
  return (
    <>
      <WSSection label="At cursor · τ = 512 s">
        <div style={{ padding: '10px 0' }}>
          <div style={{ fontSize: 22, color: wsTheme.accent, fontWeight: 500, letterSpacing: -0.4, fontVariantNumeric: 'tabular-nums' }}>1.512e-13</div>
          <div style={{ fontSize: 10.5, color: wsTheme.muted, marginTop: 2 }}>σ_y(τ) · 1σ χ² CI · EDF = 78</div>
          <div style={{ marginTop: 6, height: 4, background: wsTheme.panelAlt, borderRadius: 2, position: 'relative', overflow: 'hidden' }}>
            <div style={{ position: 'absolute', left: '38%', width: '24%', height: '100%', background: wsTheme.accentDim }} />
            <div style={{ position: 'absolute', left: '50%', width: 1, height: '100%', background: wsTheme.accent }} />
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 9.5, color: wsTheme.mutedDim, marginTop: 3 }}>
            <span>1.38e-13</span><span>1.66e-13</span>
          </div>
        </div>
      </WSSection>
      <WSSection label="σ_y(τ) table · 15 τ">
        <WSTableHead cols={['τ (s)', 'ADEV', 'MDEV', 'HDEV']} />
        {TAUS.map((t, i) => (
          <WSTableRow key={i} selected={i === 9}
            cells={[t.toLocaleString().padStart(6), fmtSci(ADEV[i], 2), fmtSci(MDEV[i], 2), fmtSci(HDEV[i], 2)]} />
        ))}
      </WSSection>
    </>
  );
}
function InspRun({ dataset }) {
  return (
    <WSSection label="Run configuration">
      <KvRow k="Source"    v={`${dataset.name}.tim`} />
      <KvRow k="Type"      v="phase data" />
      <KvRow k="N"         v={dataset.pts} />
      <KvRow k="τ₀"        v="1.000 s" />
      <KvRow k="Estimators" v="ADEV · MDEV · HDEV" hi />
      <KvRow k="Method"    v="overlapping" />
      <KvRow k="Octave"    v="m = 2ⁿ · τ₀" />
      <KvRow k="m range"   v="1 … 16 384" />
      <KvRow k="CI"        v="χ² · 1σ · EDF" />
      <KvRow k="Drift"     v="linear · removed" />
      <KvRow k="Outliers"  v="142 masked · ±5σ MAD" warn />
      <KvRow k="Gaps"      v="0" />
      <div style={{ paddingTop: 12, color: wsTheme.muted, fontSize: 10.5, lineHeight: 1.6 }}>
        <span style={{ color: wsTheme.fg, fontWeight: 600 }}>References</span><br />
        Riley · Stable32 Handbook (NIST SP 1065)<br />
        Greenhall · χ² CI for ADEV (1991)
      </div>
    </WSSection>
  );
}
function InspNoise() {
  const rows = [
    { tau: 'τ ≤ 64',     type: 'White FM',    mu: '−1.00 ± 0.04', alpha: '0',  color: wsTheme.t2 },
    { tau: '64 — 1024',  type: 'Flicker FM',  mu: '+0.02 ± 0.06', alpha: '−1', color: wsTheme.warn },
    { tau: '> 1024',     type: 'Random walk', mu: '+1.04 ± 0.10', alpha: '−2', color: wsTheme.t3 },
  ];
  return (
    <>
      <WSSection label="Identified regimes · B1 + R(1)">
        {rows.map((r, i) => (
          <div key={i} style={{ display: 'grid', gridTemplateColumns: '70px 1fr 78px', gap: 6, padding: '5px 0', borderBottom: `1px dotted ${wsTheme.border}`, alignItems: 'center', fontVariantNumeric: 'tabular-nums' }}>
            <span style={{ color: wsTheme.muted }}>{r.tau}</span>
            <span style={{ display: 'flex', alignItems: 'center', gap: 7, color: wsTheme.fg }}>
              <span style={{ width: 6, height: 6, borderRadius: 3, background: r.color }} />
              {r.type}
            </span>
            <span style={{ textAlign: 'right', color: wsTheme.fg }}>μ {r.mu.split(' ±')[0]}</span>
          </div>
        ))}
      </WSSection>
      <WSSection label="Power-law coefficients · h_α">
        <KvRow k="h₀ (W FM)"   v="9.0 × 10⁻²⁴" />
        <KvRow k="h₋₁ (F FM)"  v="4.5 × 10⁻²⁸" hi />
        <KvRow k="h₋₂ (RW FM)" v="2.1 × 10⁻³¹" />
        <KvRow k="h₊₁ (F PM)"  v="—" />
        <KvRow k="h₊₂ (W PM)"  v="—" />
      </WSSection>
    </>
  );
}
function InspMasks() {
  return (
    <>
      <WSSection label="Outlier mask">
        <KvRow k="Criterion"   v="±5σ · MAD" />
        <KvRow k="Detected"    v="142" hi />
        <KvRow k="Of"          v="99 999" />
        <KvRow k="Fraction"    v="0.142 %" />
        <KvRow k="Window"      v="rolling · 1001" />
      </WSSection>
      <WSSection label="Manual masks">
        <div style={{ padding: '4px 0', fontSize: 10.5, color: wsTheme.muted, fontStyle: 'italic' }}>none</div>
      </WSSection>
      <WSSection label="Masked indices · first 12">
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 4, fontSize: 10.5, color: wsTheme.fgDim, fontVariantNumeric: 'tabular-nums' }}>
          {['1042', '2199', '5031', '7250', '9904', '12 388', '14 720', '18 002', '21 661', '24 109', '27 503', '31 040'].map((idx) => (
            <span key={idx} style={{ padding: '3px 6px', background: wsTheme.panelAlt, borderRadius: 2, textAlign: 'center' }}>{idx}</span>
          ))}
        </div>
      </WSSection>
    </>
  );
}
function InspLog() {
  return (
    <WSSection label="Recent">
      <div style={{ lineHeight: 1.7, color: wsTheme.fgDim, fontSize: 10.5 }}>
        <LogLine ts="14:08:42" lvl="info" msg="loaded dataset" />
        <LogLine ts="14:08:43" lvl="info" msg="142 outliers masked" />
        <LogLine ts="14:08:51" lvl="ok"   msg="σ(τ) computed · 312 ms" />
        <LogLine ts="14:08:52" lvl="info" msg="noise ID complete" />
        <LogLine ts="14:09:01" lvl="warn" msg="τ=16384 EDF=5.9 wide CI" />
      </div>
    </WSSection>
  );
}

// ─── left sidebar — three variants ─────────────────────────────
function WSLeftSidebar({ variant, datasetId, selectDataset, datasetRuns, toggleRun, expanded, toggleExpand }) {
  const props = { datasetId, selectDataset, datasetRuns, toggleRun, expanded, toggleExpand };
  if (variant === 'rail')  return <SidebarRail {...props} />;
  if (variant === 'hub')   return <SidebarHub  {...props} />;
  return <SidebarStacked   {...props} />;
}

// Variant A — single tree: each dataset expands to show its source data,
// computed σ(τ) estimators, and metadata. "Layers" are children of the dataset.
function SidebarStacked({ datasetId, selectDataset, datasetRuns, toggleRun, expanded, toggleExpand }) {
  return (
    <div style={{ width: 264, borderRight: `1px solid ${wsTheme.border}`, background: wsTheme.panel, display: 'flex', flexDirection: 'column' }}>
      <WSPanelHeader title="Datasets" count={DATASETS.length} trailing="+ · import" />
      <div style={{ flex: 1, overflow: 'auto', padding: '4px 0' }}>
        {DATASETS.map((d) => (
          <DatasetTree
            key={d.id}
            dataset={d}
            isActive={d.id === datasetId}
            isExpanded={expanded.has(d.id)}
            runs={datasetRuns[d.id] || {}}
            onSelect={() => selectDataset(d.id)}
            onToggleExpand={() => toggleExpand(d.id)}
            onToggleRun={(m) => toggleRun(d.id, m)}
          />
        ))}
      </div>
    </div>
  );
}

function DatasetTree({ dataset, isActive, isExpanded, runs, onSelect, onToggleExpand, onToggleRun }) {
  const computedCount = Object.values(runs).filter(Boolean).length;
  const kindColor = dataset.kind === 'phase' ? wsTheme.t1 : wsTheme.t2;
  return (
    <div style={{ borderBottom: `1px solid ${wsTheme.border}` }}>
      <div
        onClick={onSelect}
        style={{
          display: 'flex', alignItems: 'center', gap: 6,
          padding: '7px 10px',
          background: isActive ? '#272a30' : 'transparent',
          borderLeft: isActive ? `2px solid ${wsTheme.accent}` : '2px solid transparent',
          cursor: 'pointer',
        }}
      >
        <span
          onClick={(e) => { e.stopPropagation(); onToggleExpand(); }}
          style={{ width: 14, height: 14, display: 'flex', alignItems: 'center', justifyContent: 'center', color: wsTheme.muted, cursor: 'pointer' }}
        >
          <svg width="9" height="9" viewBox="0 0 10 10" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" style={{ transform: isExpanded ? 'rotate(90deg)' : 'none', transition: 'transform .1s' }}>
            <path d="M3 2l4 3-4 3" />
          </svg>
        </span>
        <span style={{
          fontSize: 9, fontFamily: wsTheme.fontMono, letterSpacing: 0.5,
          padding: '1.5px 5px',
          background: dataset.kind === 'phase' ? wsTheme.accentSoft : 'rgba(93,210,184,0.18)',
          color: dataset.kind === 'phase' ? wsTheme.accent : wsTheme.t2,
          borderRadius: 2, textTransform: 'uppercase', fontWeight: 600, flexShrink: 0,
        }}>{dataset.kind}</span>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontFamily: wsTheme.fontMono, fontSize: 11.5, color: isActive ? wsTheme.fg : wsTheme.fgDim, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', fontWeight: isActive ? 600 : 500 }}>
            {dataset.name}
          </div>
          <div style={{ fontSize: 9.5, color: wsTheme.mutedDim, marginTop: 1, fontFamily: wsTheme.fontMono }}>
            {dataset.pts} pts · {dataset.mtime}
            {computedCount > 0 && <span style={{ marginLeft: 6, color: wsTheme.muted }}>· {computedCount} run{computedCount > 1 ? 's' : ''}</span>}
          </div>
        </div>
      </div>
      {isExpanded && (
        <div style={{ padding: '4px 0 8px', background: wsTheme.panelDeep, borderTop: `1px solid ${wsTheme.border}` }}>
          <TreeChild>
            <svg width="12" height="10" viewBox="0 0 14 10" fill="none" stroke={kindColor} strokeWidth="1.2" strokeLinecap="round">
              {dataset.kind === 'phase'
                ? <path d="M1 5c1.5-3 2-3 3 0s2 3 3 0 2-3 3 0 1 1.5 3 0" />
                : <path d="M2 8V5 M5 8V3 M8 8V6 M11 8V4" />}
            </svg>
            <span style={{ flex: 1, color: wsTheme.fgDim }}>
              {dataset.kind === 'phase' ? 'Phase  x(t)' : 'Frequency  y(t)'}
            </span>
            <span style={{ color: wsTheme.mutedDim, fontFamily: wsTheme.fontMono, fontSize: 9.5 }}>{dataset.pts}</span>
          </TreeChild>
          {METRICS.map((m) => (
            <RunRow
              key={m.id}
              metric={m}
              checked={!!runs[m.id]}
              onToggle={() => onToggleRun(m.id)}
            />
          ))}
          <TreeChild italic>
            <span style={{ width: 12, color: wsTheme.muted, textAlign: 'center', fontSize: 10 }}>⌀</span>
            <span style={{ flex: 1, color: wsTheme.muted }}>drift</span>
            <span style={{ color: wsTheme.fgDim, fontFamily: wsTheme.fontMono, fontSize: 9.5, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', maxWidth: 140 }}>{dataset.meta.drift}</span>
          </TreeChild>
          <TreeChild italic>
            <span style={{ width: 12, color: wsTheme.muted, textAlign: 'center', fontSize: 10 }}>✕</span>
            <span style={{ flex: 1, color: wsTheme.muted }}>mask</span>
            <span style={{ color: wsTheme.fgDim, fontFamily: wsTheme.fontMono, fontSize: 9.5 }}>{dataset.meta.mask}</span>
          </TreeChild>
          <div style={{ padding: '6px 14px 2px 30px' }}>
            <span style={{ color: wsTheme.mutedDim, fontSize: 10.5, fontStyle: 'italic', cursor: 'pointer' }}>+ PSD · histogram · noise ID …</span>
          </div>
        </div>
      )}
    </div>
  );
}

function TreeChild({ children, italic }) {
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 8,
      padding: '3px 14px 3px 30px',
      fontSize: 11,
      fontStyle: italic ? 'italic' : 'normal',
      fontFamily: italic ? wsTheme.fontUI : wsTheme.fontMono,
    }}>{children}</div>
  );
}

function RunRow({ metric, checked, onToggle }) {
  return (
    <div
      onClick={onToggle}
      style={{
        display: 'flex', alignItems: 'center', gap: 8,
        padding: '3.5px 14px 3.5px 30px',
        cursor: 'pointer',
        fontSize: 11, fontFamily: wsTheme.fontMono,
      }}
    >
      <span style={{
        width: 12, height: 12, flexShrink: 0,
        borderRadius: 2,
        background: checked ? wsTheme.accent : 'transparent',
        border: checked ? 'none' : `1px solid ${wsTheme.borderStrong}`,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        color: '#16161a',
      }}>
        {checked && (
          <svg width="8" height="8" viewBox="0 0 8 8" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
            <path d="M1.5 4l2 2 3-3.5" />
          </svg>
        )}
      </span>
      <span style={{ width: 7, height: 7, borderRadius: 2, background: metric.color, opacity: checked ? 1 : 0.45, flexShrink: 0 }} />
      <span style={{ flex: 1, color: checked ? wsTheme.fg : wsTheme.muted }}>
        σ(τ) · {metric.id}
      </span>
      <span style={{ color: wsTheme.mutedDim, fontSize: 9.5 }}>{checked ? 'overlap·15τ' : ''}</span>
    </div>
  );
}

// Variant B — Activity rail (VSCode-like) + content panel
function SidebarRail({ datasetId, selectDataset, datasetRuns, toggleRun, expanded, toggleExpand }) {
  const [section, setSection] = useState('files');
  const sections = [
    { id: 'files',   label: 'Datasets', icon: 'M3 5c0-.6.4-1 1-1h3l1 1h4c.6 0 1 .4 1 1v6c0 .6-.4 1-1 1H4c-.6 0-1-.4-1-1V5z' },
    { id: 'runs',    label: 'Runs',     icon: 'M4 3.5l8 4.5-8 4.5z' },
    { id: 'compare', label: 'Compare',  icon: 'M5 3v10 M11 3v10 M2 8h12' },
    { id: 'recent',  label: 'Recent',   icon: 'M8 3a5 5 0 1 0 5 5 M8 4.5V8l2.5 2' },
    { id: 'settings',label: 'Settings', icon: 'M8 5.5a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5z M8 1.5v2 M8 12.5v2 M3 8h-2 M15 8h-2' },
  ];
  const activeDs = DATASETS.find((d) => d.id === datasetId);

  return (
    <div style={{ display: 'flex', borderRight: `1px solid ${wsTheme.border}` }}>
      {/* Rail */}
      <div style={{ width: 44, background: wsTheme.panelDeep, display: 'flex', flexDirection: 'column', borderRight: `1px solid ${wsTheme.border}` }}>
        {sections.map((s) => {
          const sel = s.id === section;
          return (
            <div
              key={s.id}
              onClick={() => setSection(s.id)}
              title={s.label}
              style={{
                height: 44, display: 'flex', alignItems: 'center', justifyContent: 'center',
                cursor: 'pointer',
                color: sel ? wsTheme.fg : wsTheme.muted,
                borderLeft: sel ? `2px solid ${wsTheme.accent}` : '2px solid transparent',
                background: sel ? wsTheme.panel : 'transparent',
              }}
            >
              <svg width={18} height={18} viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth={1.4} strokeLinecap="round" strokeLinejoin="round">
                <path d={s.icon} />
              </svg>
            </div>
          );
        })}
        <div style={{ flex: 1 }} />
        <div style={{ height: 44, display: 'flex', alignItems: 'center', justifyContent: 'center', color: wsTheme.mutedDim }}>
          <svg width={16} height={16} viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth={1.4} strokeLinecap="round">
            <path d="M8 3v10 M3 8h10" />
          </svg>
        </div>
      </div>
      {/* Content */}
      <div style={{ width: 224, background: wsTheme.panel, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
        <div style={{ height: 30, padding: '0 14px', display: 'flex', alignItems: 'center', borderBottom: `1px solid ${wsTheme.border}`, background: wsTheme.panelDeep, fontSize: 11, color: wsTheme.fg, fontWeight: 600, letterSpacing: 0.3 }}>
          {sections.find((s) => s.id === section).label}
          <div style={{ flex: 1 }} />
          <span style={{ color: wsTheme.muted, fontFamily: wsTheme.fontMono, fontWeight: 500, fontSize: 10.5 }}>
            {section === 'files' ? DATASETS.length : ''}
          </span>
        </div>
        <div style={{ flex: 1, overflow: 'auto' }}>
          {section === 'files' && (
            <div style={{ padding: '4px 0' }}>
              {DATASETS.map((d) => (
                <DatasetTree
                  key={d.id}
                  dataset={d}
                  isActive={d.id === datasetId}
                  isExpanded={expanded.has(d.id)}
                  runs={datasetRuns[d.id] || {}}
                  onSelect={() => selectDataset(d.id)}
                  onToggleExpand={() => toggleExpand(d.id)}
                  onToggleRun={(m) => toggleRun(d.id, m)}
                />
              ))}
            </div>
          )}
          {section === 'runs' && (
            <div style={{ padding: '6px 0', fontFamily: wsTheme.fontMono, fontSize: 11 }}>
              {[
                { name: 'σ(τ) ADEV/MDEV/HDEV', sub: '15 τ · 312 ms · cached', ok: true },
                { name: 'noise ID · B1+R(n)',  sub: '3 regimes · 14 ms', ok: true },
                { name: 'drift fit · linear',  sub: 'a=1.74e-14/s · removed', ok: true },
                { name: 'PSD · Lomb',          sub: '4096 freq · 1.2 s', ok: false },
                { name: 'σ(τ) TDEV',           sub: 'queued', queued: true },
              ].map((r, i) => (
                <div key={i} style={{ padding: '6px 14px', display: 'flex', alignItems: 'center', gap: 8 }}>
                  <span style={{ width: 6, height: 6, borderRadius: 3, background: r.queued ? wsTheme.mutedDim : r.ok ? wsTheme.ok : wsTheme.muted }} />
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ color: wsTheme.fg, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{r.name}</div>
                    <div style={{ color: wsTheme.mutedDim, fontSize: 9.5 }}>{r.sub}</div>
                  </div>
                </div>
              ))}
            </div>
          )}
          /* layers section removed — runs are now per-dataset in the tree */
          {section === 'compare' && (
            <div style={{ padding: '12px 14px', fontFamily: wsTheme.fontMono, fontSize: 11, color: wsTheme.fgDim }}>
              <div style={{ color: wsTheme.muted, fontSize: 9.5, letterSpacing: 1, marginBottom: 8, textTransform: 'uppercase' }}>Overlay set</div>
              <CompareCard color={wsTheme.t1} name="Cs5071A — ADEV" pts="99 999" />
              <CompareCard color={wsTheme.ghost} name="OCXO-A — ADEV" pts="86 400" dashed />
              <div style={{ marginTop: 8, padding: '6px 8px', border: `1px dashed ${wsTheme.border}`, borderRadius: 3, color: wsTheme.mutedDim, textAlign: 'center', cursor: 'pointer' }}>+ Add overlay</div>
            </div>
          )}
          {section === 'recent' && (
            <div style={{ padding: '6px 0', fontFamily: wsTheme.fontMono, fontSize: 10.5, color: wsTheme.fgDim }}>
              {['14:09 Cs5071A · σ(τ) recomputed', '13:42 OCXO-A · drift fit', '11:18 MASER-03 · PSD', 'Yesterday Rb-02 · σ(τ)'].map((l, i) => (
                <div key={i} style={{ padding: '5px 14px' }}>
                  <div style={{ color: wsTheme.fg }}>{l.replace(/^\S+ /, '')}</div>
                  <div style={{ color: wsTheme.mutedDim, fontSize: 9.5 }}>{l.split(' ')[0]}</div>
                </div>
              ))}
            </div>
          )}
          {section === 'settings' && (
            <div style={{ padding: 14, fontSize: 11, color: wsTheme.muted, fontStyle: 'italic' }}>Workspace preferences live here.</div>
          )}
        </div>
      </div>
    </div>
  );
}

// Variant C — Hub: pinned recent runs as cards with mini sparklines, then datasets
function SidebarHub({ datasetId, selectDataset }) {
  return (
    <div style={{ width: 264, borderRight: `1px solid ${wsTheme.border}`, background: wsTheme.panel, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      {/* Search */}
      <div style={{ padding: 10, borderBottom: `1px solid ${wsTheme.border}`, background: wsTheme.panelDeep }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 7, padding: '0 10px', height: 26, background: wsTheme.panel, border: `1px solid ${wsTheme.border}`, borderRadius: 3 }}>
          <svg width={11} height={11} viewBox="0 0 16 16" fill="none" stroke={wsTheme.muted} strokeWidth={1.4}><circle cx="7" cy="7" r="4.5"/><path d="M10.5 10.5l3 3" strokeLinecap="round"/></svg>
          <span style={{ color: wsTheme.mutedDim, fontFamily: wsTheme.fontMono, fontSize: 11 }}>find run, dataset…</span>
          <div style={{ flex: 1 }} />
          <span style={{ color: wsTheme.mutedDim, fontFamily: wsTheme.fontMono, fontSize: 10 }}>⌘P</span>
        </div>
      </div>
      <WSPanelHeader title="Pinned runs" count="3" />
      <div style={{ padding: '8px 10px' }}>
        <RunCard color={wsTheme.t1} name="Cs5071A · today" floor="1.52e-14" trace={ADEV} active={datasetId === 'cs5071'} onClick={() => selectDataset('cs5071')} />
        <RunCard color={wsTheme.t2} name="OCXO-A · 2d ago" floor="6.4e-13" trace={ADEV.map((v) => v * 4.2)} active={datasetId === 'ocxo-a'} onClick={() => selectDataset('ocxo-a')} />
        <RunCard color={wsTheme.t3} name="MASER-03 · 4d"   floor="8.2e-15" trace={ADEV.map((v) => v * 0.4)} active={datasetId === 'maser03'} onClick={() => selectDataset('maser03')} />
      </div>
      <WSPanelHeader title="All datasets" count={DATASETS.length} />
      <div style={{ flex: 1, overflow: 'auto', padding: '4px 0', fontFamily: wsTheme.fontMono, fontSize: 11 }}>
        {DATASETS.map((d) => (
          <WSDataset key={d.id} name={d.name} sub={`${d.kind} · ${d.pts} pts · ${d.mtime}`} active={d.id === datasetId} onClick={() => selectDataset(d.id)} />
        ))}
      </div>
    </div>
  );
}
function CompareCard({ color, name, pts, dashed }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '6px 8px', background: wsTheme.panelDeep, borderRadius: 3, marginBottom: 5, fontSize: 11 }}>
      <span style={{ width: 12, borderTop: `2px ${dashed ? 'dashed' : 'solid'} ${color}` }} />
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ color: wsTheme.fg, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{name}</div>
        <div style={{ color: wsTheme.mutedDim, fontSize: 9.5 }}>{pts} pts</div>
      </div>
      <span style={{ color: wsTheme.mutedDim, fontSize: 14 }}>×</span>
    </div>
  );
}
function RunCard({ color, name, floor, trace, active, onClick }) {
  // tiny log-log sparkline
  const W = 124, H = 30;
  const xs = TAUS.map((t) => Math.log10(t) / Math.log10(32768));
  const ymin = -15, ymax = -10;
  const ys = trace.map((v) => (Math.log10(v) - ymin) / (ymax - ymin));
  const path = trace.map((v, i) => `${i ? 'L' : 'M'}${(xs[i] * W).toFixed(1)},${((1 - ys[i]) * H).toFixed(1)}`).join(' ');
  return (
    <div onClick={onClick} style={{
      padding: 10, marginBottom: 6, cursor: 'pointer',
      background: active ? wsTheme.panelDeep : wsTheme.panelAlt,
      border: active ? `1px solid ${wsTheme.accent}` : `1px solid ${wsTheme.border}`,
      borderRadius: 3,
    }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 6 }}>
        <span style={{ fontSize: 11, color: wsTheme.fg, fontWeight: 500, fontFamily: wsTheme.fontMono }}>{name}</span>
        <span style={{ fontSize: 9.5, color: wsTheme.mutedDim, fontFamily: wsTheme.fontMono }}>floor</span>
      </div>
      <svg width={W} height={H} style={{ display: 'block' }}>
        <path d={path} fill="none" stroke={color} strokeWidth={1.4} />
      </svg>
      <div style={{ marginTop: 4, color: wsTheme.fg, fontFamily: wsTheme.fontMono, fontSize: 12, fontVariantNumeric: 'tabular-nums' }}>{floor}</div>
    </div>
  );
}

// ─── shared helpers ────────────────────────────────────────────
function SigmaTauMark() {
  return (
    <div style={{ display: 'flex', alignItems: 'baseline', gap: 10, lineHeight: 1 }}>
      <span style={{ display: 'inline-flex', alignItems: 'baseline', fontFamily: wsTheme.fontUI, fontWeight: 500, letterSpacing: -0.5, lineHeight: 1 }}>
        <span style={{ fontSize: 22, color: wsTheme.accent, fontStyle: 'italic' }}>σ</span>
        <span style={{ fontSize: 19, color: wsTheme.mutedDim, margin: '0 0px 0 1px' }}>(</span>
        <span style={{ fontSize: 20, color: wsTheme.tau, fontStyle: 'italic' }}>τ</span>
        <span style={{ fontSize: 19, color: wsTheme.mutedDim }}>)</span>
      </span>
      <span style={{ fontFamily: wsTheme.fontUI, fontSize: 14, fontWeight: 600, letterSpacing: -0.3, lineHeight: 1 }}>
        <span style={{ color: wsTheme.accent }}>Sigma</span><span style={{ color: wsTheme.tau }}>Tau</span>
      </span>
    </div>
  );
}
function WSGroup({ children }) {
  return <div style={{ display: 'flex', gap: 2, background: wsTheme.panelDeep, padding: 2, borderRadius: 4, border: `1px solid ${wsTheme.border}` }}>{children}</div>;
}
function WSSep() { return <div style={{ width: 1, height: 18, background: wsTheme.border, margin: '0 4px' }} />; }
function WSPill({ label, active, primary, warn, glyph, color, onClick }) {
  const [hover, setHover] = useState(false);
  const baseBg = primary ? wsTheme.accent : active ? wsTheme.panelAlt : 'transparent';
  return (
    <div
      onClick={onClick}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={{
        display: 'flex', alignItems: 'center', gap: 5,
        height: 22, padding: '0 8px', borderRadius: 3,
        background: hover && onClick && !primary ? wsTheme.border : baseBg,
        color: primary ? '#1a1a1d' : warn ? wsTheme.warn : active ? wsTheme.fg : wsTheme.muted,
        fontSize: 10.5, fontWeight: primary ? 600 : 500,
        fontFamily: wsTheme.fontMono, whiteSpace: 'nowrap',
        cursor: onClick ? 'pointer' : 'default',
        userSelect: 'none',
        transition: 'background 0.08s',
      }}
    >
      {glyph && <span style={{ color: color || 'inherit', fontSize: 9, opacity: active ? 1 : 0.5 }}>{glyph}</span>}
      {label}
    </div>
  );
}
function WSPanelHeader({ title, count, trailing }) {
  return (
    <div style={{ height: 24, display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '0 12px', background: wsTheme.panelDeep, borderBottom: `1px solid ${wsTheme.border}`, fontSize: 10, color: wsTheme.muted, letterSpacing: 1, textTransform: 'uppercase' }}>
      <span>{title}</span>
      <span style={{ fontFamily: wsTheme.fontMono, letterSpacing: 0, textTransform: 'none' }}>{trailing || count}</span>
    </div>
  );
}
function WSDataset({ name, sub, active, onClick }) {
  const [hover, setHover] = useState(false);
  return (
    <div
      onClick={onClick}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={{
        padding: '5px 12px',
        borderLeft: active ? `2px solid ${wsTheme.accent}` : '2px solid transparent',
        background: active ? '#272a30' : hover && onClick ? wsTheme.panelAlt : 'transparent',
        cursor: onClick ? 'pointer' : 'default',
      }}
    >
      <div style={{ fontSize: 11, color: active ? wsTheme.fg : wsTheme.fgDim, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{name}</div>
      <div style={{ fontSize: 9.5, color: wsTheme.mutedDim, marginTop: 1 }}>{sub}</div>
    </div>
  );
}
function WSLayer({ color, name, sub, dashed, hidden, onClick }) {
  return (
    <div onClick={onClick} style={{
      display: 'flex', alignItems: 'center', gap: 8, padding: '4px 12px',
      opacity: hidden ? 0.45 : 1,
      cursor: onClick ? 'pointer' : 'default',
    }}>
      <span style={{ width: 7, height: 7, borderRadius: 2, background: color, border: dashed ? `1.5px dashed ${color}` : 'none', boxSizing: 'border-box' }} />
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: 11, color: wsTheme.fgDim, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{name}</div>
        <div style={{ fontSize: 9.5, color: wsTheme.mutedDim }}>{sub}</div>
      </div>
      <span style={{ fontSize: 9.5, color: wsTheme.mutedDim }}>{hidden ? '◌' : '●'}</span>
    </div>
  );
}
function WSSection({ label, children }) {
  return (
    <div>
      <div style={{ padding: '8px 12px 4px', fontSize: 10, color: wsTheme.muted, letterSpacing: 1, textTransform: 'uppercase', background: wsTheme.panelDeep, borderBottom: `1px solid ${wsTheme.border}`, fontFamily: wsTheme.fontUI, fontWeight: 600 }}>{label}</div>
      <div style={{ padding: '0 12px 8px' }}>{children}</div>
    </div>
  );
}
function WSTableHead({ cols }) {
  return (
    <div style={{ display: 'grid', gridTemplateColumns: '56px 1fr 1fr 1fr', gap: 6, fontSize: 9.5, color: wsTheme.mutedDim, padding: '6px 4px 4px', borderBottom: `1px solid ${wsTheme.border}`, letterSpacing: 0.4 }}>
      {cols.map((c) => <span key={c} style={{ textAlign: c === 'τ (s)' ? 'right' : 'left' }}>{c}</span>)}
    </div>
  );
}
function WSTableRow({ cells, selected }) {
  return (
    <div style={{ display: 'grid', gridTemplateColumns: '56px 1fr 1fr 1fr', gap: 6, fontSize: 10.5, padding: '2.5px 4px', background: selected ? '#272a30' : 'transparent', color: selected ? wsTheme.accent : wsTheme.fgDim, fontVariantNumeric: 'tabular-nums', borderLeft: selected ? `2px solid ${wsTheme.accent}` : '2px solid transparent', marginLeft: -2 }}>
      <span style={{ textAlign: 'right', color: selected ? wsTheme.accent : wsTheme.muted }}>{cells[0]}</span>
      <span>{cells[1]}</span><span>{cells[2]}</span><span>{cells[3]}</span>
    </div>
  );
}
function KvRow({ k, v, hi, warn }) {
  return (
    <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: `1px dotted ${wsTheme.border}` }}>
      <span style={{ color: wsTheme.muted }}>{k}</span>
      <span style={{ color: warn ? wsTheme.warn : hi ? wsTheme.accent : wsTheme.fg, fontWeight: hi ? 600 : 400, fontVariantNumeric: 'tabular-nums' }}>{v}</span>
    </div>
  );
}
function LogLine({ ts, lvl, msg }) {
  const colors = { info: wsTheme.muted, ok: wsTheme.ok, warn: wsTheme.warn, err: wsTheme.err };
  const tags = { info: 'INFO', ok: ' OK ', warn: 'WARN', err: 'ERR ' };
  return (
    <div style={{ display: 'flex', gap: 10, whiteSpace: 'nowrap' }}>
      <span style={{ color: wsTheme.mutedDim }}>{ts}</span>
      <span style={{ color: colors[lvl], width: 36 }}>[{tags[lvl]}]</span>
      <span style={{ overflow: 'hidden', textOverflow: 'ellipsis' }}>{msg}</span>
    </div>
  );
}

Object.assign(window, { WSWindow, wsTheme });
