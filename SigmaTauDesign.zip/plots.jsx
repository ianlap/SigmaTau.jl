// plots.jsx — shared mock data + themed SVG plots for SigmaTau variations.
// All plots take a `theme` prop with colors + fonts so each variation can
// restyle without touching layout logic.

// ─────────────────────────────────────────────────────────────
// Mock data — realistic stability of a Cs beam vs H-maser reference,
// N = 100k samples, τ0 = 1 s.
// ADEV bottoms out around τ ~ 1000 s at ~1.5e-14, then random-walk FM rises.
// ─────────────────────────────────────────────────────────────
const TAUS = [1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048, 4096, 8192, 16384];

function _stab(tau, c) {
  // composite: white-FM + flicker floor + random-walk FM
  const wfm = c.wfm / Math.sqrt(tau);
  const ff  = c.ff;
  const rw  = c.rw * Math.sqrt(tau);
  return Math.sqrt(wfm * wfm + ff * ff + rw * rw);
}
const ADEV = TAUS.map((t) => _stab(t, { wfm: 3.0e-12, ff: 1.8e-14, rw: 7e-16 }));
const MDEV = TAUS.map((t) => _stab(t, { wfm: 1.8e-12, ff: 1.5e-14, rw: 6e-16 }));
const HDEV = TAUS.map((t) => _stab(t, { wfm: 3.2e-12, ff: 1.9e-14, rw: 4e-16 }));
const TDEV = TAUS.map((t, i) => MDEV[i] * t / Math.sqrt(3)); // s
// 1-σ chi-square half-widths (rough EDF-based, multiplicative)
const EDF  = TAUS.map((t) => Math.max(1.4, 99999 / (2.5 * t)));
const CI   = EDF.map((edf) => Math.sqrt(edf / (edf - 0.5)) - 1); // ~fractional

// Noise-type fit slopes (μ in σ ~ τ^(μ/2)) — the canonical set
const NOISE_BANDS = [
  { label: 'W PM', mu: -2, color: 0 },
  { label: 'F PM', mu: -2, color: 1 },
  { label: 'W FM', mu: -1, color: 2 },
  { label: 'F FM', mu:  0, color: 3 },
  { label: 'RW FM', mu: 1, color: 4 },
];

// Time-series phase data (mock): linear drift + WFM noise. Returns N points
// downsampled to `n` for path drawing.
function phaseSeries(n = 600, seed = 7) {
  let s = seed, r = () => (s = (s * 9301 + 49297) % 233280) / 233280;
  const pts = [];
  let x = 0;
  for (let i = 0; i < n; i++) {
    x += (r() - 0.5) * 0.8 + 0.02; // drift + walk
    pts.push(x + Math.sin(i * 0.04) * 0.4);
  }
  return pts;
}
function frequencySeries(n = 600, seed = 13) {
  let s = seed, r = () => (s = (s * 9301 + 49297) % 233280) / 233280;
  const pts = [];
  let v = 0;
  for (let i = 0; i < n; i++) {
    v = v * 0.92 + (r() - 0.5) * 0.6;
    pts.push(v + 0.0008 * i); // tiny drift
  }
  return pts;
}
function histogramBins(n = 32, seed = 21) {
  let s = seed, r = () => (s = (s * 9301 + 49297) % 233280) / 233280;
  const out = [];
  for (let i = 0; i < n; i++) {
    const x = (i - n / 2) / (n / 6);
    const g = Math.exp(-x * x / 2);
    out.push(g * (0.7 + r() * 0.4));
  }
  return out;
}
function psdSeries(n = 220, seed = 41) {
  // Slope ~ f^-1 (flicker) on log-log + bumps
  let s = seed, r = () => (s = (s * 9301 + 49297) % 233280) / 233280;
  const out = [];
  for (let i = 0; i < n; i++) {
    const f = Math.pow(10, -3 + (i / n) * 4); // 1e-3 .. 10 Hz
    const base = 1e-22 / f + 1e-25 + (1e-26) * f * f;
    const bump = (i > n * 0.45 && i < n * 0.5) ? 6e-24 : 0;
    out.push({ f, p: base * (0.6 + r() * 0.8) + bump });
  }
  return out;
}

// ─────────────────────────────────────────────────────────────
// Log-log axis helper.
// ─────────────────────────────────────────────────────────────
function logAxis(min, max, range) {
  const lmin = Math.log10(min), lmax = Math.log10(max);
  return (v) => ((Math.log10(v) - lmin) / (lmax - lmin)) * range;
}
function decadeTicks(min, max) {
  const out = [];
  for (let d = Math.ceil(Math.log10(min)); d <= Math.floor(Math.log10(max)); d++) {
    out.push(Math.pow(10, d));
  }
  return out;
}
function minorLogTicks(min, max) {
  const out = [];
  for (let d = Math.floor(Math.log10(min)); d <= Math.ceil(Math.log10(max)); d++) {
    for (let k = 2; k <= 9; k++) {
      const v = k * Math.pow(10, d);
      if (v >= min && v <= max) out.push(v);
    }
  }
  return out;
}
function fmtSci(v, digits = 1) {
  if (v === 0) return '0';
  const e = Math.floor(Math.log10(Math.abs(v)));
  const m = v / Math.pow(10, e);
  return `${m.toFixed(digits)}e${e >= 0 ? '+' : ''}${e}`;
}
function fmtSciSup(v, digits = 0) {
  if (v === 0) return ['0', ''];
  const e = Math.floor(Math.log10(Math.abs(v)));
  const m = v / Math.pow(10, e);
  const mantissa = digits === 0 ? '' : m.toFixed(digits);
  return [mantissa, e];
}

// ─────────────────────────────────────────────────────────────
// <SigmaTauPlot> — the hero plot. log-log, multiple traces, error bars,
// power-law fit lines, hover readout, legend. Theme-driven.
// ─────────────────────────────────────────────────────────────
function SigmaTauPlot({
  theme,
  width = 700, height = 460,
  pad = { t: 28, r: 28, b: 56, l: 76 },
  traces = ['ADEV', 'MDEV', 'HDEV'],
  showErrorBars = true,
  showFit = true,
  showNoiseBands = false,
  showCursor = true,
  cursorIdx = 9, // points to τ=512
  comparison = null, // optional second dataset {ADEV: [...]}
  axisStyle = 'graticule', // 'graticule' | 'minimal' | 'paper'
  legend = 'inline', // 'inline' | 'right' | 'top'
  title,
  glow = false,
}) {
  const W = width, H = height;
  const pw = W - pad.l - pad.r, ph = H - pad.t - pad.b;
  const xMin = 1, xMax = 32768;
  const yMin = 1e-15, yMax = 1e-10;
  const xs = logAxis(xMin, xMax, pw);
  const ys = (v) => ph - logAxis(yMin, yMax, ph)(v);

  const traceMap = { ADEV, MDEV, HDEV, TDEV };
  const colorMap = {
    ADEV: theme.t1, MDEV: theme.t2, HDEV: theme.t3, TDEV: theme.t4,
  };
  const pathFor = (data) => data.map((v, i) => `${i ? 'L' : 'M'}${xs(TAUS[i]).toFixed(2)},${ys(v).toFixed(2)}`).join(' ');

  // Power-law fit segments (illustrative, white-FM and RW-FM)
  const fitWFM = (t) => 3.0e-12 / Math.sqrt(t);
  const fitRWFM = (t) => 7e-16 * Math.sqrt(t);

  return (
    <svg width={W} height={H} style={{ display: 'block', overflow: 'visible' }}
      fontFamily={theme.fontMono}>
      <defs>
        {glow && (
          <filter id={`glow-${theme.id}`} x="-20%" y="-20%" width="140%" height="140%">
            <feGaussianBlur stdDeviation="2.2" result="b" />
            <feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge>
          </filter>
        )}
      </defs>
      <g transform={`translate(${pad.l},${pad.t})`}>
        {/* background */}
        <rect x={0} y={0} width={pw} height={ph} fill={theme.plotBg} stroke={axisStyle === 'paper' ? theme.axis : 'none'} strokeWidth={axisStyle === 'paper' ? 1 : 0} />

        {/* noise type bands (under everything) */}
        {showNoiseBands && (
          <g opacity={0.35}>
            {/* white FM band shading τ in [1, 64] */}
            <rect x={xs(1)} y={0} width={xs(64) - xs(1)} height={ph} fill={theme.bandWfm || 'transparent'} />
            <rect x={xs(64)} y={0} width={xs(2048) - xs(64)} height={ph} fill={theme.bandFfm || 'transparent'} />
            <rect x={xs(2048)} y={0} width={xs(32768) - xs(2048)} height={ph} fill={theme.bandRwfm || 'transparent'} />
          </g>
        )}

        {/* minor grid */}
        {axisStyle !== 'minimal' && (
          <g stroke={theme.gridMinor} strokeWidth={axisStyle === 'graticule' ? 0.4 : 0.5} opacity={axisStyle === 'paper' ? 0.5 : 1}>
            {minorLogTicks(xMin, xMax).map((t) => (
              <line key={`mx${t}`} x1={xs(t)} x2={xs(t)} y1={0} y2={ph} />
            ))}
            {minorLogTicks(yMin, yMax).map((v) => (
              <line key={`my${v}`} x1={0} x2={pw} y1={ys(v)} y2={ys(v)} />
            ))}
          </g>
        )}
        {/* major grid */}
        <g stroke={theme.grid} strokeWidth={axisStyle === 'paper' ? 0.6 : 0.8}>
          {decadeTicks(xMin, xMax).map((t) => (
            <line key={`mjx${t}`} x1={xs(t)} x2={xs(t)} y1={0} y2={ph} />
          ))}
          {decadeTicks(yMin, yMax).map((v) => (
            <line key={`mjy${v}`} x1={0} x2={pw} y1={ys(v)} y2={ys(v)} />
          ))}
        </g>

        {/* power-law fit lines */}
        {showFit && (
          <g stroke={theme.fitColor} strokeWidth={1} strokeDasharray="4 4" opacity={0.9} fill="none">
            <line x1={xs(1)} y1={ys(fitWFM(1))} x2={xs(64)} y2={ys(fitWFM(64))} />
            <line x1={xs(4096)} y1={ys(fitRWFM(4096))} x2={xs(32768)} y2={ys(fitRWFM(32768))} />
            <text x={xs(8)} y={ys(fitWFM(8)) - 6} fill={theme.fitColor} fontSize={10} style={{ fontStyle: 'italic' }}>τ⁻¹⁄²  (W FM)</text>
            <text x={xs(10000)} y={ys(fitRWFM(10000)) - 6} fill={theme.fitColor} fontSize={10} style={{ fontStyle: 'italic' }}>τ⁺¹⁄²  (RW FM)</text>
          </g>
        )}

        {/* comparison ghost trace */}
        {comparison && (
          <path d={pathFor(comparison.ADEV)} fill="none" stroke={theme.ghost} strokeWidth={1.4} strokeDasharray="2 3" opacity={0.7} />
        )}

        {/* error bars */}
        {showErrorBars && traces.includes('ADEV') && (
          <g stroke={colorMap.ADEV} strokeWidth={1} opacity={0.55}>
            {ADEV.map((v, i) => {
              const x = xs(TAUS[i]);
              const yHi = ys(v * (1 + CI[i] * 1.4));
              const yLo = ys(v * (1 - CI[i] * 0.9));
              return (
                <g key={`eb${i}`}>
                  <line x1={x} x2={x} y1={yLo} y2={yHi} />
                  <line x1={x - 3} x2={x + 3} y1={yHi} y2={yHi} />
                  <line x1={x - 3} x2={x + 3} y1={yLo} y2={yLo} />
                </g>
              );
            })}
          </g>
        )}

        {/* traces */}
        <g filter={glow ? `url(#glow-${theme.id})` : undefined}>
          {traces.map((name) => (
            <g key={name}>
              <path d={pathFor(traceMap[name])} fill="none" stroke={colorMap[name]} strokeWidth={1.8} />
              {traceMap[name].map((v, i) => (
                <g key={`${name}-pt-${i}`} transform={`translate(${xs(TAUS[i])},${ys(v)})`}>
                  {name === 'ADEV' && <rect x={-3} y={-3} width={6} height={6} fill={colorMap[name]} stroke={theme.plotBg} strokeWidth={1} />}
                  {name === 'MDEV' && <circle r={3} fill={colorMap[name]} stroke={theme.plotBg} strokeWidth={1} />}
                  {name === 'HDEV' && <polygon points="0,-3.6 3.2,2 -3.2,2" fill={colorMap[name]} stroke={theme.plotBg} strokeWidth={1} />}
                  {name === 'TDEV' && <polygon points="0,-3.4 3.4,0 0,3.4 -3.4,0" fill={colorMap[name]} stroke={theme.plotBg} strokeWidth={1} />}
                </g>
              ))}
            </g>
          ))}
        </g>

        {/* cursor */}
        {showCursor && (() => {
          const t = TAUS[cursorIdx], v = ADEV[cursorIdx];
          const cx = xs(t), cy = ys(v);
          return (
            <g>
              <line x1={cx} x2={cx} y1={0} y2={ph} stroke={theme.cursor} strokeWidth={0.8} strokeDasharray="2 3" />
              <line x1={0} x2={pw} y1={cy} y2={cy} stroke={theme.cursor} strokeWidth={0.8} strokeDasharray="2 3" />
              <circle cx={cx} cy={cy} r={5} fill="none" stroke={theme.cursor} strokeWidth={1.4} />
              {/* readout */}
              <g transform={`translate(${cx + 12}, ${cy - 56})`}>
                <rect x={0} y={0} width={148} height={50} rx={4} fill={theme.readoutBg} stroke={theme.readoutBorder} strokeWidth={0.8} />
                <text x={9} y={14} fontSize={10} fill={theme.muted} letterSpacing={0.4}>τ = {t.toLocaleString()} s</text>
                <text x={9} y={28} fontSize={11} fill={theme.fg} fontWeight={600}>σy = {fmtSci(v, 3)}</text>
                <text x={9} y={42} fontSize={10} fill={theme.muted}>noise: W FM · μ ≈ −1</text>
              </g>
            </g>
          );
        })()}

        {/* axes */}
        <line x1={0} x2={pw} y1={ph} y2={ph} stroke={theme.axis} strokeWidth={1.2} />
        <line x1={0} x2={0} y1={0} y2={ph} stroke={theme.axis} strokeWidth={1.2} />
        {decadeTicks(xMin, xMax).map((t) => (
          <g key={`tx${t}`} transform={`translate(${xs(t)},${ph})`}>
            <line y1={0} y2={5} stroke={theme.axis} strokeWidth={1} />
            <text y={18} fontSize={11} fill={theme.muted} textAnchor="middle">
              10<tspan baselineShift="super" fontSize={8}>{Math.round(Math.log10(t))}</tspan>
            </text>
          </g>
        ))}
        {decadeTicks(yMin, yMax).map((v) => (
          <g key={`ty${v}`} transform={`translate(0,${ys(v)})`}>
            <line x1={-5} x2={0} stroke={theme.axis} strokeWidth={1} />
            <text x={-9} y={3.5} fontSize={11} fill={theme.muted} textAnchor="end">
              10<tspan baselineShift="super" fontSize={8}>{Math.round(Math.log10(v))}</tspan>
            </text>
          </g>
        ))}

        {/* axis labels */}
        <text x={pw / 2} y={ph + 40} textAnchor="middle" fontSize={12} fill={theme.fg} fontFamily={theme.fontUI}>
          Averaging time  τ  (s)
        </text>
        <text transform={`translate(${-58},${ph / 2}) rotate(-90)`} textAnchor="middle" fontSize={12} fill={theme.fg} fontFamily={theme.fontUI}>
          Allan deviation  σ<tspan baselineShift="sub" fontSize={9}>y</tspan>(τ)
        </text>

        {title && (
          <text x={0} y={-10} fontSize={12} fill={theme.fg} fontFamily={theme.fontUI} fontWeight={600}>
            {title}
          </text>
        )}

        {/* inline legend (top-right of plot area) */}
        {legend === 'inline' && (
          <g transform={`translate(${pw - 142}, 14)`}>
            <rect x={-8} y={-12} width={150} height={traces.length * 16 + 12} fill={theme.readoutBg} stroke={theme.readoutBorder} strokeWidth={0.6} rx={3} />
            {traces.map((name, i) => (
              <g key={name} transform={`translate(0, ${i * 16})`}>
                <line x1={0} x2={18} y1={0} y2={0} stroke={colorMap[name]} strokeWidth={1.8} />
                {name === 'ADEV' && <rect x={6} y={-3} width={6} height={6} fill={colorMap[name]} stroke={theme.plotBg} strokeWidth={1} />}
                {name === 'MDEV' && <circle cx={9} cy={0} r={3} fill={colorMap[name]} stroke={theme.plotBg} strokeWidth={1} />}
                {name === 'HDEV' && <polygon points="9,-3.6 12.2,2 5.8,2" fill={colorMap[name]} stroke={theme.plotBg} strokeWidth={1} />}
                {name === 'TDEV' && <polygon points="9,-3.4 12.4,0 9,3.4 5.6,0" fill={colorMap[name]} stroke={theme.plotBg} strokeWidth={1} />}
                <text x={24} y={3.5} fontSize={10.5} fill={theme.fg}>{name}</text>
              </g>
            ))}
          </g>
        )}
      </g>
    </svg>
  );
}

// ─────────────────────────────────────────────────────────────
// <TimeSeriesPlot> — phase OR fractional frequency vs time.
// ─────────────────────────────────────────────────────────────
function TimeSeriesPlot({ theme, width = 380, height = 140, kind = 'phase', pad = { t: 14, r: 12, b: 22, l: 46 } }) {
  const W = width, H = height;
  const pw = W - pad.l - pad.r, ph = H - pad.t - pad.b;
  const series = kind === 'phase' ? phaseSeries(pw | 0) : frequencySeries(pw | 0);
  const min = Math.min(...series), max = Math.max(...series);
  const span = max - min || 1;
  const y = (v) => ph - ((v - min) / span) * ph;
  const path = series.map((v, i) => `${i ? 'L' : 'M'}${(i * pw / series.length).toFixed(1)},${y(v).toFixed(1)}`).join(' ');
  const yTicks = [min, (min + max) / 2, max];

  return (
    <svg width={W} height={H} style={{ display: 'block' }} fontFamily={theme.fontMono}>
      <g transform={`translate(${pad.l},${pad.t})`}>
        <rect x={0} y={0} width={pw} height={ph} fill={theme.plotBg} />
        <g stroke={theme.gridMinor} strokeWidth={0.4}>
          {[0.25, 0.5, 0.75].map((f) => (
            <line key={`gx${f}`} x1={f * pw} x2={f * pw} y1={0} y2={ph} />
          ))}
          {[0.25, 0.5, 0.75].map((f) => (
            <line key={`gy${f}`} x1={0} x2={pw} y1={f * ph} y2={f * ph} />
          ))}
        </g>
        <path d={path} fill="none" stroke={kind === 'phase' ? theme.t1 : theme.t2} strokeWidth={1.1} />
        <line x1={0} x2={pw} y1={ph} y2={ph} stroke={theme.axis} strokeWidth={1} />
        <line x1={0} x2={0} y1={0} y2={ph} stroke={theme.axis} strokeWidth={1} />
        {yTicks.map((v, i) => (
          <g key={i} transform={`translate(0,${y(v)})`}>
            <line x1={-3} x2={0} stroke={theme.axis} strokeWidth={1} />
            <text x={-6} y={3} fontSize={9.5} fill={theme.muted} textAnchor="end">{fmtSci(v, 1)}</text>
          </g>
        ))}
        <text x={pw / 2} y={ph + 16} textAnchor="middle" fontSize={9.5} fill={theme.muted}>t (s) · 0 → 10⁵</text>
        <text transform={`translate(${-36}, ${ph / 2}) rotate(-90)`} textAnchor="middle" fontSize={9.5} fill={theme.muted}>{kind === 'phase' ? 'x(t) / ns' : 'y(t)'}</text>
      </g>
    </svg>
  );
}

// ─────────────────────────────────────────────────────────────
// <Histogram> — distribution of fractional frequency.
// ─────────────────────────────────────────────────────────────
function Histogram({ theme, width = 240, height = 120, pad = { t: 8, r: 8, b: 18, l: 30 } }) {
  const W = width, H = height;
  const pw = W - pad.l - pad.r, ph = H - pad.t - pad.b;
  const bins = histogramBins(28);
  const max = Math.max(...bins);
  const bw = pw / bins.length;
  return (
    <svg width={W} height={H} style={{ display: 'block' }} fontFamily={theme.fontMono}>
      <g transform={`translate(${pad.l},${pad.t})`}>
        <rect x={0} y={0} width={pw} height={ph} fill={theme.plotBg} />
        {bins.map((v, i) => {
          const h = (v / max) * ph;
          return <rect key={i} x={i * bw + 0.5} y={ph - h} width={bw - 1} height={h} fill={theme.t2} opacity={0.75} />;
        })}
        {/* gaussian overlay */}
        <path d={
          Array.from({ length: 60 }, (_, k) => {
            const x = (k / 59) * pw;
            const g = Math.exp(-Math.pow((k - 30) / 8, 2) / 2);
            return `${k ? 'L' : 'M'}${x.toFixed(1)},${(ph - g * ph * 0.95).toFixed(1)}`;
          }).join(' ')
        } fill="none" stroke={theme.fg} strokeWidth={1} strokeDasharray="3 2" opacity={0.6} />
        <line x1={0} x2={pw} y1={ph} y2={ph} stroke={theme.axis} strokeWidth={1} />
        <line x1={0} x2={0} y1={0} y2={ph} stroke={theme.axis} strokeWidth={1} />
        <text x={pw / 2} y={ph + 14} textAnchor="middle" fontSize={9.5} fill={theme.muted}>y · 1e-12</text>
      </g>
    </svg>
  );
}

// ─────────────────────────────────────────────────────────────
// <PSDPlot> — Lomb periodogram, log-log
// ─────────────────────────────────────────────────────────────
function PSDPlot({ theme, width = 320, height = 180, pad = { t: 12, r: 12, b: 26, l: 48 } }) {
  const W = width, H = height;
  const pw = W - pad.l - pad.r, ph = H - pad.t - pad.b;
  const data = psdSeries(120);
  const fMin = 1e-3, fMax = 10, pMin = 1e-26, pMax = 1e-20;
  const xs = logAxis(fMin, fMax, pw);
  const ys = (v) => ph - logAxis(pMin, pMax, ph)(v);
  const path = data.map(({ f, p }, i) => `${i ? 'L' : 'M'}${xs(f).toFixed(1)},${ys(Math.max(pMin, Math.min(pMax, p))).toFixed(1)}`).join(' ');
  return (
    <svg width={W} height={H} style={{ display: 'block' }} fontFamily={theme.fontMono}>
      <g transform={`translate(${pad.l},${pad.t})`}>
        <rect x={0} y={0} width={pw} height={ph} fill={theme.plotBg} />
        <g stroke={theme.gridMinor} strokeWidth={0.4}>
          {decadeTicks(fMin, fMax).map((f) => (
            <line key={f} x1={xs(f)} x2={xs(f)} y1={0} y2={ph} />
          ))}
          {decadeTicks(pMin, pMax).map((p) => (
            <line key={p} x1={0} x2={pw} y1={ys(p)} y2={ys(p)} />
          ))}
        </g>
        <path d={path} fill="none" stroke={theme.t3} strokeWidth={1.2} />
        {/* slope guide */}
        <line x1={xs(0.01)} y1={ys(1e-21)} x2={xs(1)} y2={ys(1e-23)} stroke={theme.fitColor} strokeWidth={1} strokeDasharray="3 3" />
        <line x1={0} x2={pw} y1={ph} y2={ph} stroke={theme.axis} strokeWidth={1} />
        <line x1={0} x2={0} y1={0} y2={ph} stroke={theme.axis} strokeWidth={1} />
        {decadeTicks(fMin, fMax).map((f) => (
          <g key={`tx${f}`} transform={`translate(${xs(f)},${ph})`}>
            <line y1={0} y2={3} stroke={theme.axis} strokeWidth={1} />
            <text y={14} fontSize={9} fill={theme.muted} textAnchor="middle">10<tspan baselineShift="super" fontSize={7}>{Math.round(Math.log10(f))}</tspan></text>
          </g>
        ))}
        {decadeTicks(pMin, pMax).map((p) => (
          <g key={`ty${p}`} transform={`translate(0,${ys(p)})`}>
            <line x1={-3} x2={0} stroke={theme.axis} strokeWidth={1} />
            <text x={-6} y={3} fontSize={9} fill={theme.muted} textAnchor="end">10<tspan baselineShift="super" fontSize={7}>{Math.round(Math.log10(p))}</tspan></text>
          </g>
        ))}
        <text x={pw / 2} y={ph + 22} textAnchor="middle" fontSize={10} fill={theme.fg}>f (Hz)</text>
        <text transform={`translate(${-38}, ${ph / 2}) rotate(-90)`} textAnchor="middle" fontSize={10} fill={theme.fg}>S_y(f)</text>
      </g>
    </svg>
  );
}

Object.assign(window, {
  SigmaTauPlot, TimeSeriesPlot, Histogram, PSDPlot,
  TAUS, ADEV, MDEV, HDEV, TDEV, CI, fmtSci, fmtSciSup,
});
